package com.local.qobuzremote;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Google Play services wakes this service when a connected watch sends a command. */
public class WatchListener extends WearableListenerService {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override public void onMessageReceived(MessageEvent event) {
        if (!"/qobuz/cmd".equals(event.getPath())) return;
        String cmd = new String(event.getData(), StandardCharsets.UTF_8);
        String sender = event.getSourceNodeId();
        executor.execute(() -> {
            String reply;
            try { reply = "电视：" + TvBridgeClient.command(getApplicationContext(), cmd); }
            catch (Exception e) { reply = "失败：" + e.getMessage(); }
            Wearable.getMessageClient(getApplicationContext())
                .sendMessage(sender, "/qobuz/status", reply.getBytes(StandardCharsets.UTF_8));
        });
    }
    @Override public void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
