package com.local.qobuzremote;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Locale;

/** Home-LAN prototype protocol. The TV PIN authorizes a client token. No Internet server. */
public final class TvBridgeClient {
    public static final int PORT = 43811;
    private static final String PREFS = "bridge_config";
    private TvBridgeClient() {}

    public static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String exchange(String host, String message) throws Exception {
        if (host == null || !host.matches("[0-9a-fA-F.:]+") || host.length() > 64)
            throw new IllegalArgumentException("请输入电视的 IPv4 地址（例如 192.168.1.50）");
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, PORT), 4000);
            socket.setSoTimeout(5000);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());
            out.writeUTF(message);
            out.flush();
            String reply = in.readUTF();
            if (!reply.startsWith("OK|"))
                throw new IllegalStateException(reply.startsWith("ERR|") ? reply.substring(4) : "电视响应异常");
            return reply.substring(3);
        }
    }

    public static String pair(Context ctx, String host, String pin) throws Exception {
        String normalized = pin.trim().toUpperCase(Locale.ROOT);
        if (!normalized.matches("[0-9]{6}"))
            throw new IllegalArgumentException("请输入电视显示的六位配对码");
        String token = exchange(host.trim(), "PAIR|" + normalized);
        if (!token.matches("[0-9a-f]{64}"))
            throw new IllegalStateException("电视返回的令牌格式不正确");
        prefs(ctx).edit().putString("host", host.trim()).putString("token", token).apply();
        return "配对成功，手机与电视已关联";
    }

    public static String command(Context ctx, String operation) throws Exception {
        if (!operation.matches("OPEN|PLAY_PAUSE|PLAY|PAUSE|NEXT|PREV|VOL_UP|VOL_DOWN|STATUS"))
            throw new IllegalArgumentException("不支持的操作");
        SharedPreferences p = prefs(ctx);
        String host = p.getString("host", "");
        String token = p.getString("token", "");
        if (host.isEmpty() || token.isEmpty()) throw new IllegalStateException("请先在手机上配对 Google TV");
        return exchange(host, "CMD|" + token + "|" + operation);
    }
}
