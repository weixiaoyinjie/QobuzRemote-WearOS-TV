package com.local.qobuzremote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText ip, pin;
    private TextView status;
    private LinearLayout content;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,14,22));
        getWindow().setNavigationBarColor(Color.rgb(11,14,22));
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.rgb(11,14,22));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(34), dp(24), dp(24));
        scroller.addView(content);
        setContentView(scroller);
        label("QOBUZ REMOTE", 29, Color.WHITE);
        label("手机 + Wear OS + Google TV", 15, 0xFFB2B8C8);
        space(22);
        label("① 先打开电视上的 Qobuz TV Bridge", 18, Color.WHITE);
        label("电视会显示 IP 地址与六位配对码。", 14, 0xFFB2B8C8);
        ip = entry("电视 IP 地址", TvBridgeClient.prefs(this).getString("host", ""));
        pin = entry("电视显示的六位配对码", "");
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        button("连接并配对电视", () -> runBackground(() -> TvBridgeClient.pair(this, ip.getText().toString().trim(), pin.getText().toString().trim())));
        space(22);
        label("② Qobuz 电视控制", 18, Color.WHITE);
        button("▶ 打开电视上的 Qobuz", () -> cmd("OPEN"));
        button("⏯ 播放 / 暂停", () -> cmd("PLAY_PAUSE"));
        LinearLayout playback = new LinearLayout(this);
        playback.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(playback);
        smallButton(playback, "⏮ 上一首", () -> cmd("PREV"));
        smallButton(playback, "下一首 ⏭", () -> cmd("NEXT"));
        LinearLayout volumes = new LinearLayout(this);
        volumes.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(volumes);
        smallButton(volumes, "音量 −", () -> cmd("VOL_DOWN"));
        smallButton(volumes, "音量 +", () -> cmd("VOL_UP"));
        button("检查电视连接 / 播放会话", () -> cmd("STATUS"));
        space(16);
        label("③ 手表", 18, Color.WHITE);
        label("安装手表 APK 后，手表通过 Wear OS Data Layer 将按钮指令发送到已配对的手机，手机再转发给电视。", 14, 0xFFB2B8C8);
        space(16);
        status = label("未连接：先在电视上启动 Bridge 并配对。", 14, 0xFF92D8D3);
    }

    private void cmd(String operation) {
        runBackground(() -> TvBridgeClient.command(this, operation));
    }

    private interface NetworkCall { String call() throws Exception; }
    private void runBackground(NetworkCall call) {
        status.setText("正在向电视发送指令…");
        executor.execute(() -> {
            try {
                String result = call.call();
                runOnUiThread(() -> status.setText("电视响应：" + result));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("失败：" + e.getMessage()));
            }
        });
    }

    private TextView label(String value, int textSize, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(textSize);
        view.setTextColor(color);
        view.setPadding(0, dp(5), 0, dp(6));
        content.addView(view);
        return view;
    }
    private EditText entry(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(0xFF9099A7);
        input.setTextColor(Color.WHITE);
        input.setSingleLine(true);
        input.setText(value);
        content.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        return input;
    }
    private void button(String value, Runnable command) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setOnClickListener(v -> command.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        p.topMargin = dp(6);
        content.addView(b, p);
    }
    private void smallButton(LinearLayout parent, String value, Runnable command) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setOnClickListener(v -> command.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        parent.addView(b, p);
    }
    private void space(int dp) {
        android.view.View view = new android.view.View(this);
        content.addView(view, new LinearLayout.LayoutParams(1, dp(dp)));
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
