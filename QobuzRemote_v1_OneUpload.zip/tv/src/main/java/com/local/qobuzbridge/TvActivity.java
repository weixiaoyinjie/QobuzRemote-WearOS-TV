package com.local.qobuzbridge;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.InetAddress;
import java.security.SecureRandom;
import java.util.Collections;

public class TvActivity extends Activity {
    private TextView pinView, details;
    private final SecureRandom random = new SecureRandom();
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,14,22));
        content = new LinearLayout(this);
        content.setPadding(dp(45), dp(24), dp(45), dp(20));
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.rgb(11,14,22));
        setContentView(content);
        addText("QOBUZ  ·  TV BRIDGE", 26, Color.WHITE);
        addText("将手机和手表连接到这台 Google TV", 16, 0xFFB5C3CD);
        addText("① 电视 IP 地址", 18, 0xFF91D7D1);
        addText(findAddress(), 27, Color.WHITE);
        addText("② 六位配对码（手机输入）", 18, 0xFF91D7D1);
        pinView = addText("", 40, Color.WHITE);
        details = addText("", 15, 0xFFB5C3CD);
        button("刷新配对码", () -> refreshPin());
        button("授权读取 TV 的播放会话（控制切歌所需）", () -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { details.setText("无法打开授权设置：" + e.getMessage()); }
        });
        button("打开电视上的 Qobuz（本机测试）", () -> {
            try { details.setText(BridgeActions.openQobuz(this)); }
            catch (Exception e) { details.setText(e.getMessage()); }
        });
        button("检查播放权限", () -> details.setText("电视播放会话访问：" +
            (hasSessionPermission() ? "已授权" : "尚未授权，请在系统通知使用权中启用 Qobuz 播放控制")));
        addText("配对完成后可返回主界面。Qobuz 播放声音仍通过原来的 HDMI ARC 路径。", 14, 0xFFB5C3CD);
        refreshPin();
        Intent svc = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
    }

    private boolean hasSessionPermission() {
        String listeners = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return listeners != null && listeners.contains(getPackageName());
    }

    private void refreshPin() {
        String pin = String.format(java.util.Locale.ROOT, "%06d", random.nextInt(1_000_000));
        getSharedPreferences("bridge", MODE_PRIVATE).edit()
            .putString("pin", pin)
            .putLong("pin_deadline", System.currentTimeMillis() + 5 * 60 * 1000L)
            .putInt("pin_attempts", 0)
            .apply();
        pinView.setText(pin);
        details.setText("配对码有效期 5 分钟。电视端口：43811。播放会话权限：" + (hasSessionPermission() ? "已授权" : "未授权"));
    }

    private String findAddress() {
        try {
            String fallback = null;
            for (NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!iface.isUp() || iface.isLoopback() || iface.isVirtual()) continue;
                for (InetAddress addr : Collections.list(iface.getInetAddresses())) {
                    if (!(addr instanceof Inet4Address) || addr.isLoopbackAddress() || addr.isLinkLocalAddress()) continue;
                    if (iface.getName().startsWith("wlan") || iface.getName().startsWith("eth")) return addr.getHostAddress();
                    fallback = addr.getHostAddress();
                }
            }
            return fallback != null ? fallback : "请检查电视网络连接";
        } catch (Exception e) { return "无法读取 IP 地址"; }
    }

    private TextView addText(String s, int size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0, dp(5), 0, dp(8));
        content.addView(v);
        return v;
    }
    private void button(String s, Runnable action) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(600), dp(52));
        params.topMargin = dp(7);
        content.addView(b, params);
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
}
