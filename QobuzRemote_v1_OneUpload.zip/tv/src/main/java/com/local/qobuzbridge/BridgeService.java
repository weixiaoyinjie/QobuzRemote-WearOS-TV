package com.local.qobuzbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.Process;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** LAN-only, authenticated TV command bridge. No cloud connection; command reply is synchronous. */
public class BridgeService extends Service {
    private static final int PORT = 43811;
    private static final String CHANNEL = "bridge_running";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean running;
    private volatile ServerSocket listener;
    private final SecureRandom rng = new SecureRandom();

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(new NotificationChannel(
            CHANNEL, "Qobuz TV Bridge 连接服务", NotificationManager.IMPORTANCE_LOW));
        PendingIntent action = PendingIntent.getActivity(this, 0, new Intent(this, TvActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
            .setContentTitle("Qobuz TV Bridge 已运行")
            .setContentText("手机/手表可以在局域网控制 Qobuz")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).setContentIntent(action).build();
        startForeground(2150, n);
        running = true;
        worker.execute(this::serve);
    }

    private void serve() {
        try (ServerSocket server = new ServerSocket(PORT)) {
            listener = server;
            server.setSoTimeout(1000);
            while (running) {
                try (Socket socket = server.accept()) {
                    socket.setSoTimeout(5000);
                    DataInputStream in = new DataInputStream(socket.getInputStream());
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                    String response;
                    try { response = handle(in.readUTF()); }
                    catch (Exception e) { response = "ERR|" + safe(e.getMessage()); }
                    out.writeUTF(response);
                    out.flush();
                } catch (SocketTimeoutException ignored) {
                    // Allows the service to shut down without leaking a blocking thread.
                } catch (Exception ignored) {
                    // A failed client must not terminate the local receiver.
                }
            }
        } catch (Exception ignored) {
            // Port may already be occupied; notification stays up, app log indicates failure.
        } finally { listener = null; }
    }

    private synchronized String handle(String packet) throws Exception {
        if (packet == null || packet.length() > 512) return "ERR|数据太长";
        SharedPreferences p = getSharedPreferences("bridge", MODE_PRIVATE);
        if (packet.startsWith("PAIR|")) {
            String pin = packet.substring(5);
            long expiry = p.getLong("pin_deadline", 0);
            int attempts = p.getInt("pin_attempts", 0);
            if (System.currentTimeMillis() > expiry || p.getString("pin", "").isEmpty())
                return "ERR|电视配对码已过期，请在电视上刷新";
            if (attempts >= 5) return "ERR|错误次数过多，请在电视上刷新配对码";
            if (!pin.equals(p.getString("pin", ""))) {
                p.edit().putInt("pin_attempts", attempts + 1).apply();
                return "ERR|配对码错误";
            }
            byte[] bytes = new byte[32];
            rng.nextBytes(bytes);
            StringBuilder b = new StringBuilder();
            for (byte item : bytes) b.append(String.format(java.util.Locale.ROOT, "%02x", item & 0xff));
            String token = b.toString();
            p.edit().putString("token", token).remove("pin").remove("pin_deadline").apply();
            return "OK|" + token;
        }
        String[] parts = packet.split("\\|", -1);
        if (parts.length != 3 || !"CMD".equals(parts[0])) return "ERR|命令格式错误";
        String token = p.getString("token", "");
        if (token.isEmpty() || !constantTimeEquals(token, parts[1])) return "ERR|没有控制权限，请重新配对";
        if (!parts[2].matches("OPEN|PLAY_PAUSE|PLAY|PAUSE|NEXT|PREV|VOL_UP|VOL_DOWN|STATUS"))
            return "ERR|不支持的操作";
        return "OK|" + BridgeActions.handle(this, parts[2]);
    }

    private static boolean constantTimeEquals(String expected, String supplied) {
        return java.security.MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.US_ASCII),
            supplied.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }
    private static String safe(String s) {
        return s == null ? "未知错误" : s.replace('|','/').replace('\n',' ').substring(0, Math.min(s.length(), 160));
    }
    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onDestroy() {
        running = false;
        try { if (listener != null) listener.close(); } catch (Exception ignored) { }
        worker.shutdownNow();
        super.onDestroy();
    }
}
