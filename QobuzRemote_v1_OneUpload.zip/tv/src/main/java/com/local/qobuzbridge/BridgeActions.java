package com.local.qobuzbridge;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.view.KeyEvent;
import java.util.List;

final class BridgeActions {
    private static final String QOBUZ_PACKAGE = "com.qobuz.music";

    static String handle(Context ctx, String op) throws Exception {
        switch (op) {
            case "OPEN": return openQobuz(ctx);
            case "STATUS": {
                MediaController mc = session(ctx);
                return mc == null
                    ? "已连接 TV Bridge；未找到 Qobuz 播放会话（确认播放会话访问权限，并在 Qobuz 中开始播放）"
                    : "已连接 TV Bridge；找到 Qobuz 播放会话：" + mc.getPackageName();
            }
            case "VOL_UP": case "VOL_DOWN": {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (am == null) throw new IllegalStateException("电视音频服务不可用");
                am.adjustSuggestedStreamVolume("VOL_UP".equals(op) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                    AudioManager.USE_DEFAULT_STREAM_TYPE, 0);
                return "已发送电视音量指令（HDMI ARC / CEC 是否响应取决于电视设置）";
            }
        }
        MediaController controller = session(ctx);
        if (controller == null)
            throw new IllegalStateException("未找到 Qobuz 播放会话。先在电视系统授权 Qobuz 播放控制，然后在 Qobuz 播放一首歌。");
        MediaController.TransportControls tc = controller.getTransportControls();
        switch (op) {
            case "PLAY": tc.play(); break;
            case "PAUSE": tc.pause(); break;
            case "NEXT": tc.skipToNext(); break;
            case "PREV": tc.skipToPrevious(); break;
            case "PLAY_PAUSE": {
                PlaybackState state = controller.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) tc.pause();
                else tc.play();
                break;
            }
            default: throw new IllegalArgumentException("不认识的指令");
        }
        return "已发送 " + op + " 到 Qobuz 媒体会话";
    }

    static String openQobuz(Context ctx) throws Exception {
        Intent launch = ctx.getPackageManager().getLeanbackLaunchIntentForPackage(QOBUZ_PACKAGE);
        if (launch == null) launch = ctx.getPackageManager().getLaunchIntentForPackage(QOBUZ_PACKAGE);
        if (launch == null) throw new IllegalStateException("电视未找到 Qobuz。请先从电视 Play 商店安装 Qobuz。");
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        ctx.startActivity(launch);
        return "已发送启动 Qobuz 指令";
    }

    private static MediaController session(Context ctx) {
        try {
            MediaSessionManager mgr = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (mgr == null) return null;
            ComponentName listener = new ComponentName(ctx, TvNotificationListener.class);
            List<MediaController> sessions = mgr.getActiveSessions(listener);
            for (MediaController mc : sessions) {
                if (QOBUZ_PACKAGE.equals(mc.getPackageName())) return mc;
            }
        } catch (SecurityException ignored) { }
        return null;
    }
}
