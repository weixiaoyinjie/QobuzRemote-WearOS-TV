package com.local.qobuzbridge;

import android.service.notification.NotificationListenerService;

/** Permission gate for MediaSessionManager.getActiveSessions(ComponentName). */
public class TvNotificationListener extends NotificationListenerService { }
