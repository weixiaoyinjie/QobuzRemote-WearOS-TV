# Qobuz Remote v1.0 – 手机 + Wear OS + Google TV

本版本是**可编译的实验工程**（未经过你的真机验证），并非 Qobuz 官方 App，也没有使用 Qobuz Connect 私有 API。

## 包含三个 Android APK

- `tv-debug.apk`：安装到 Google TV。用于启动电视上的 Qobuz、访问播放会话、接收局域网遥控命令。
- `phone-debug.apk`：安装到 Android 手机。先配对 TV，以后可直接控制，同时作为手表消息转发端。
- `watch-debug.apk`：安装到 Wear OS 手表。使用手机中转指令。

**注意**：手机 APK 和手表 APK 的 applicationId 均为 `com.local.qobuzremote`，必须采用相同签名密钥构建。GitHub Actions 同一个 job 构建出的这两个 debug APK 可满足此要求。电视 APK 为 `com.local.qobuzbridge`，独立包名。

## 安装与首次连接

1. Google TV 上已经安装 **Qobuz**，确认可以使用实体遥控器操作其播放。
2. TV 上安装 `tv-debug.apk`（可使用你已有的文件管理器/安装 APK 的方法），启动 **Qobuz TV Bridge**。
3. TV 屏幕会显示 IP 地址、六位数配对码。码有效期 5 分钟。Bridge 前台服务开始运行。
4. 在 TV Bridge 中点击 **授权读取 TV 的播放会话**，在系统「通知使用权 / Notification access」中允许 **Qobuz 播放控制**，然后返回。部分电视固件可能没有这项权限设置；未授权时仍可一键打开 Qobuz，但可能无法切歌。
5. 在 Android 手机安装 `phone-debug.apk`，打开 Qobuz Remote，输入 TV IP 与六位码，点击 **连接并配对电视**。
6. 测试手机按钮 **打开电视上的 Qobuz**，再播放一首歌，测试播放/暂停与切歌。
7. 在已与手机配对的 Wear OS 手表安装 `watch-debug.apk`，打开 Qobuz Remote，点击 **打开 Qobuz**，手机将命令转发给电视。手表与手机应连接到 Wear OS Data Layer（Google Play 服务）。
8. 建议路由器为 Google TV 绑定固定的局域网 IP；IP 变化后需要在手机里重新填写并配对。

## 功能与边界

- `OPEN`：`PackageManager.getLeanbackLaunchIntentForPackage("com.qobuz.music")` 直接启动**电视上已安装的** Qobuz；不跳到 Play 商店搜索页面。
- 播放/暂停、上一首/下一首：通过电视端 `MediaSessionManager` + Qobuz 的 `MediaController.TransportControls`，**必须存在可访问的 Qobuz 媒体会话**。电视系统可能不支持第三方获取媒体会话，因此不能保证每台设备都能控制。
- 音量：通过电视端 `AudioManager` 调整系统音量。部分设备 HDMI ARC/CEC 采取固定音量或由外置音响独立控制，本功能可能无效。无法确保直接调节 W510。
- 手机到 TV Bridge 采用 **仅限私有可信 Wi-Fi 的 TCP 指令协议**（43811 端口），六位配对码用于换取随机 256 位令牌，配对码有时效与尝试次数限制。由于没有 TLS，这**不是对抗不可信局域网抓包者的加密方案**。不要在公共 Wi-Fi 或共享办公网络使用。
- 不包含自动开机、自动选歌、读取 Qobuz 高音质信息、封面/播放列表、Qobuz 帐号登录、Qobuz Connect 遥控。
- 手机与手表必须安装同一套构建输出、使用兼容的 Google Play Services / Wear OS Data Layer。手机可以不打开 UI，但手机需要在线且能够访问 TV IP。
- TV Bridge 必须处于运行状态。Android TV 重启/系统强杀后台后，可能需要重新启动 TV Bridge。
- 手机/手表只控制播放指令，不转码、不改变 TV → HDMI ARC → S61B + W510 的音频路径。

## GitHub Actions 自动编译（适合只用手机操作）

1. 创建 GitHub 仓库（可以设为私有），把 `QobuzRemote_v1_OneUpload.zip` 上传到仓库根目录。
2. 在 GitHub 仓库的 **Add file → Create new file** 中新建 `.github/workflows/build-apk.yml`，将同包里同名文件的全部内容粘贴保存。若源码直接解压上传到仓库，使用 Android Studio 或 `gradle :phone:assembleDebug :watch:assembleDebug :tv:assembleDebug`。
3. 在 Actions 中打开 **Build Qobuz Remote (Phone + Wear + TV)**，点击 **Run workflow**。
4. 构建成功后从该工作流运行记录页面下载 **QobuzRemote-v1-Phone-Wear-TV**，内含三个 APK。

编译需要 JDK17、Android SDK35、Google/MavenCentral/Gradle 在线依赖。工作流采用 AGP 8.7.3 + Gradle 8.11.1。

## 测试顺序

- **第一关：TV Bridge 页面能显示 IP + PIN → 手机配对成功。**
- **第二关：手机的 OPEN 键能直接打开 TV Qobuz。**
- **第三关：TV 授权媒体会话后，手机的播放/切歌能生效。**
- **第四关：手表点击 OPEN，电视响应、手表看到来自电视的结果。**
- **第五关：手表切歌、音量、Google TV 重启之后的行为验证。**

如果某一关失败，保留对应的 TV/手机/手表截图和 GitHub Actions 构建日志，用实际结果修改下一版。
