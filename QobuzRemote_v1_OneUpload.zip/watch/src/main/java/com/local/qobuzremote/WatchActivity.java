package com.local.qobuzremote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.android.gms.wearable.MessageClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class WatchActivity extends Activity implements MessageClient.OnMessageReceivedListener {
    private TextView status;
    private LinearLayout body;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroller = new ScrollView(this);
        scroller.setBackgroundColor(Color.rgb(11,14,22));
        body = new LinearLayout(this);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(19);
        body.setPadding(pad, dp(15), pad, dp(30));
        scroller.addView(body);
        setContentView(scroller);
        text("QOBUZ", 21, 0xFFFFFFFF);
        text("GOOGLE TV", 12, 0xFF91D6D0);
        button("▶ 打开 Qobuz", "OPEN");
        button("⏯ 播放 / 暂停", "PLAY_PAUSE");
        button("⏮ 上一首", "PREV");
        button("下一首 ⏭", "NEXT");
        button("音量 ＋", "VOL_UP");
        button("音量 －", "VOL_DOWN");
        status = text("手表 → 手机 → 电视", 11, 0xFFBEC9D3);
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(3), 0, dp(4));
        body.addView(t);
        return t;
    }
    private void button(String title, String code) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(14);
        b.setOnClickListener(v -> send(code));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(49));
        lp.topMargin = dp(2);
        body.addView(b, lp);
    }
    private void send(String code) {
        status.setText("正在发送…");
        Wearable.getNodeClient(this).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                if (nodes == null || nodes.isEmpty()) { status.setText("未连接手机"); return; }
                Node phone = null;
                for (Node n : nodes) if (n.isNearby()) { phone = n; break; }
                if (phone == null) phone = nodes.get(0);
                Wearable.getMessageClient(this)
                    .sendMessage(phone.getId(), "/qobuz/cmd", code.getBytes(StandardCharsets.UTF_8))
                    .addOnSuccessListener(id -> status.setText("已发送给手机，等待电视响应"))
                    .addOnFailureListener(e -> status.setText("发送失败：" + e.getMessage()));
            }).addOnFailureListener(e -> status.setText("没有手机连接：" + e.getMessage()));
    }
    @Override public void onMessageReceived(MessageEvent event) {
        if ("/qobuz/status".equals(event.getPath())) {
            String reply = new String(event.getData(), StandardCharsets.UTF_8);
            runOnUiThread(() -> status.setText(reply));
        }
    }
    @Override protected void onResume() { super.onResume(); Wearable.getMessageClient(this).addListener(this); }
    @Override protected void onPause() { Wearable.getMessageClient(this).removeListener(this); super.onPause(); }
    private int dp(int px) { return (int)(px * getResources().getDisplayMetrics().density + .5f); }
}
